package data;

import java.io.Serializable;
import java.time.LocalDate;

public class ProfissionalSaude extends Utilizador implements Serializable{

    private static final long serialVersionUID = 2650540891875656129L;
    private String num_trabalhador, profissao, especialidade;

    public ProfissionalSaude(String num_trabalhador, String profissao, String especialidade) {
        this.num_trabalhador = num_trabalhador;
        this.profissao = profissao;
        this.especialidade = especialidade;
    }

    public ProfissionalSaude(String nome, String nif, String cc, LocalDate datanasc, String num_trabalhador, String profissao, String especialidade) {
        super(nome, nif, cc, datanasc);
        this.num_trabalhador = num_trabalhador;
        this.profissao = profissao;
        this.especialidade = especialidade;
    }

    public String getNum_trabalhador() {
        return num_trabalhador;
    }

    public void setNum_trabalhador(String num_trabalhador) {
        this.num_trabalhador = num_trabalhador;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    @Override
    public String toString() {
        return "Profissional Saúde{" +
                super.toString() +
                "numero trabalhador='" + num_trabalhador + '\'' +
                ", profissao='" + profissao + '\'' +
                ", especialidade='" + especialidade + '\'' +
                '}';
    }

}
