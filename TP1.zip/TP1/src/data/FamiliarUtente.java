package data;

import java.io.Serializable;
import java.time.LocalDate;

public class FamiliarUtente extends Utilizador implements Serializable {

    private static final long serialVersionUID = 2095039068141592120L;

    private String nome_familiar, telefone,grau_parentesco;

    public FamiliarUtente(String nome_familiar, String telefone, String grau_parentesco) {
        this.nome_familiar = nome_familiar;
        this.telefone = telefone;
        this.grau_parentesco = grau_parentesco;
    }

    public FamiliarUtente(String nome, String nif, String cc, LocalDate datanasc, String nome_familiar, String telefone, String grau_parentesco) {
        super(nome, nif, cc, datanasc);
        this.nome_familiar = nome_familiar;
        this.telefone = telefone;
        this.grau_parentesco = grau_parentesco;
    }

    public String getNome_familiar() {
        return nome_familiar;
    }

    public void setNome_familiar(String nome_familiar) {
        this.nome_familiar = nome_familiar;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getGrau_parentesco() {
        return grau_parentesco;
    }

    public void setGrau_parentesco(String grau_parentesco) {
        this.grau_parentesco = grau_parentesco;
    }

    @Override
    public String toString() {
        return "FamiliarUtente{" +
                super.toString() +
                "nome_familiar='" + nome_familiar + '\'' +
                ", telefone='" + telefone + '\'' +
                ", grau_parentesco='" + grau_parentesco + '\'' +
                '}';
    }
}

