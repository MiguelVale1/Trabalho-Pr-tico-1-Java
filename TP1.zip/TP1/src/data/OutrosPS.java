package data;

public class OutrosPS extends ProfissionalSaude {
    private String nome, tipoPS;

    public OutrosPS (String num_trabalhador, String profissao, String especialidade, String nome, String tipoPS) {
        super (num_trabalhador,profissao, especialidade);
        this.nome = nome;
        this.tipoPS = tipoPS;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipoPS() {
        return tipoPS;
    }

    public void setTipoPS(String tipoPS) {
        this.tipoPS = tipoPS;
    }

    @Override
    public String toString() {
        return "OutrosPS{" +
                "nome='" + nome + '\'' +
                ", tipoPS='" + tipoPS + '\'' +
                '}';
    }
}
