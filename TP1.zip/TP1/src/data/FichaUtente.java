package data;

import java.io.Serializable;
import java.util.List;

public class FichaUtente implements Serializable {
    private static final long serialVersionUID = 7924343070283612359L;
    private Utente utente;
    private FamiliarUtente familiarUtente;
    private List<Medicao> medicoes;
    private List<Prescricao> prescricoes;
    private List<Exames> exames;
    private List<Consulta> consultas;

    public FichaUtente(Utente utenteinfo) {
    }

    public Utente getUtente() {
        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }

    public FamiliarUtente getFamiliarUtente() {
        return familiarUtente;
    }

    public void setFamiliarUtente(FamiliarUtente familiarUtente) {
        this.familiarUtente = familiarUtente;
    }

    public List<Medicao> getMedicoes() {
        return medicoes;
    }

    public void setMedicoes(List<Medicao> medicoes) {
        this.medicoes = medicoes;
    }

    public List<Prescricao> getPrescricoes() {
        return prescricoes;
    }

    public void setPrescricoes(List<Prescricao> prescricoes) {
        this.prescricoes = prescricoes;
    }

    public List<Exames> getExames() {
        return exames;
    }

    public void setExames(List<Exames> exames) {
        this.exames = exames;
    }

    public List<Consulta> getConsultas() {
        return consultas;
    }

    public void setConsultas(List<Consulta> consultas) {
        this.consultas = consultas;
    }

    public FichaUtente (Utente utente, FamiliarUtente familiarUtente, List<Medicao> medicoes, List<Prescricao> prescricoes, List<Exames> exames, List<Consulta> consultas) {
        this.utente = utente;
        this.familiarUtente = familiarUtente;
        this.medicoes = medicoes;
        this.prescricoes = prescricoes;
        this.exames = exames;
        this.consultas = consultas;
}

    @Override
    public String toString() {
        return "Ficha de Utente {" +
                "utente=" + utente +
                ", familiar do utente=" + familiarUtente +
                ", medições=" + medicoes +
                ", prescrições válidas=" + prescricoes +
                ", consultas=" + consultas + '\'' +
                '}';
    }
}
