package data.excepcoes;

import java.rmi.RemoteException;

public class ProfissionalNaoExiste extends RemoteException {

}
