package data.excepcoes;

import java.rmi.RemoteException;

public class UtenteExiste extends RemoteException {
}



