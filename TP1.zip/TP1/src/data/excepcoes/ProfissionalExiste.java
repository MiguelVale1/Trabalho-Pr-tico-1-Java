package data.excepcoes;

import java.rmi.RemoteException;

public class ProfissionalExiste extends RemoteException {
}



