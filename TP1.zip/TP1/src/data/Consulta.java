package data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Consulta implements Serializable {

    private static final long serialVersionUID = -74661440005618893L;

    private LocalDateTime data;

    private ProfissionalSaude profissionalSaude;

    private List<Prescricao> prescriçoes;

    private List<Exames> exames;

    private String observaçoes;

    public Consulta(LocalDateTime data, ProfissionalSaude profissionalSaude, List<Prescricao> prescriçoes, List<Exames> exames, String observaçoes) {
        this.data = data;
        this.profissionalSaude = profissionalSaude;
        this.prescriçoes = new ArrayList<>();
        this.exames = new ArrayList<>();
        this.observaçoes = observaçoes;}

    public LocalDateTime getData() {
        return data;
    }

    public void setData(LocalDateTime data) {
        this.data = data;
    }

    public ProfissionalSaude getProfissionalSaude() {
        return profissionalSaude;
    }

    public void setProfissionalSaude(ProfissionalSaude profissionalSaude) {
        this.profissionalSaude = profissionalSaude;
    }

    public List<Prescricao> getPrescriçoes() {
        return prescriçoes;
    }

    public void setPrescriçoes(List<Prescricao> prescriçoes) {
        this.prescriçoes = prescriçoes;
    }

    public List<Exames> getExames() {
        return exames;
    }

    public void setExames(List<Exames> exames) {
        this.exames = exames;
    }

    public String getObservaçoes() {
        return observaçoes;
    }

    public void setObservaçoes(String observaçoes) {
        this.observaçoes = observaçoes;
    }


    @Override
    public String toString() {
        return "Consultas { \n" +
                "data=" + data +
                ",\n observaçoes='" + observaçoes + "'" +
                ",\n prescriçoes=" + prescriçoes +
                ",\n exames=" + exames +
                ",\n profissional de saude =" + profissionalSaude +
                "}\n\n";}
}
