package configuracoes;

public class Configuracoes {
    public static Integer rmiPort = 5090;
    public static String rmiService = "unisaude";
    public static String rmiServiceLocation = "rmi://localhost:" + rmiPort + "/" + rmiService;
}
