package client;

import configuracoes.Configuracoes;
import data.FamiliarUtente;
import interfaces.UtenteInterface;

import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;

public class FamiliarUtenteCliente {
    private static FamiliarUtente service = null;


    public static void main(String[] args) throws IOException, NotBoundException {

        //service = (FamiliarUtente) Naming.lookup(Configuracoes.rmiServiceLocation);

        //var numutente = "0460925160759";

        //System.out.println("Consultar Ficha de Utente");
       // System.out.println(service.ConsultarFichaUtente(numutente));

        //service.save();
    }
}
