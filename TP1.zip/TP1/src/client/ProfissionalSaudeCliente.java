package client;

import configuracoes.Configuracoes;
import data.ProfissionalSaude;
import interfaces.UtenteInterface;

import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;

public class ProfissionalSaudeCliente {
    private static ProfissionalSaude service = null;


    public static void main(String[] args) throws IOException, NotBoundException {

        //service = (ProfissionalSaude) Naming.lookup(Configuracoes.rmiServiceLocation);

        //var codigoUtente = "0460925160759";

        //System.out.println("Consultar Ficha de Utente");
        //System.out.println(service.ConsultarFichaUtente(codigoUtente));

        //System.out.println("Atualizar Ficha de Utente");
        //System.out.println(service.AtualizarFichaUtente(codigoUtente));

        //service.save();
    }
}
