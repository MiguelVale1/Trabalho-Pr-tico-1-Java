package client;

import configuracoes.Configuracoes;
import data.ProfissionalSaude;
import data.Utente;
import interfaces.UtenteInterface;

import java.awt.*;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.Map;

public class UtenteCliente {
    private static UtenteInterface service = null;


    public static void main(String[] args) throws IOException, NotBoundException {

        service = (UtenteInterface)Naming.lookup(Configuracoes.rmiServiceLocation);
        service.AddUtente("Ariana Fernandes", "nif123123123", LocalDate.of(1994,06,23), "numutente321654987","963852741", "963258147", "afmf@afmf.pt", "4940 Paredes de Coura");
        service.save();

        System.out.println(service.GetUtente(10));

        var numutente = "321654987";

        System.out.println("Consultar Ficha de Utente");
        System.out.println(service.ConsultarFichaUtente(numutente));
    }
}
//inserir uma ficha de utente com todas as informaçoes como acontece na classe gestorclinica do outro trabalho e colocar o
//numutente aqui na variavel de baixo e ver se imprime no terminal as informaçoes





