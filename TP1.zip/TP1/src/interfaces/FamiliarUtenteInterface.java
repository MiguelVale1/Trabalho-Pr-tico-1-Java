package interfaces;

import data.FichaUtente;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface FamiliarUtenteInterface extends Remote {
    //public void ConsultarFichaUtente (FichaUtente) throws RemoteException;
}
