package interfaces;


import data.*;
import prog.PCmanager;

import java.io.IOException;
import java.io.Serializable;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.time.LocalDateTime;
import java.util.List;

public class ServicoSaude extends UnicastRemoteObject implements UtenteInterface,
        ProfissionalSaudeInterface, FamiliarUtenteInterface, Serializable {
    private static final long serialVersionUID = -5971366257757660196L;

    private PCmanager admin = null;

    public ServicoSaude(PCmanager admin) throws RemoteException {
        super();
        admin = admin;
    }

    @Override
    public void save() throws IOException, NotBoundException {

    }

    public FichaUtente ConsultarFichaUtente(String numutente) throws RemoteException {
        return admin.getFichasUtente().get(numutente);
    }

    @Override
    public void ConsultarFichaUtente() throws RemoteException {

    }

    @Override
    public void AtualizarDadosUtente(String numutente, String telefone, String telefone_familiar, String email, String morada) throws RemoteException {

    }

    @Override
    public void EditarFichaUtente(LocalDateTime data, Utente utente, FamiliarUtente familiarUtente, List<Medicao> mediçoes, List<Prescricao> prescriçoes, List<Exames> exames, List<Consulta> consultas) throws RemoteException {

    }
}
