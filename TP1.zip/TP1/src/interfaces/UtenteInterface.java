package interfaces;

import data.FichaUtente;


import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.time.LocalDate;

public interface UtenteInterface extends Remote {

        void save() throws IOException, NotBoundException;

        FichaUtente ConsultarFichaUtente(String numutente) throws RemoteException;

        void AddUtente(String arianaFernandes, String nif123123123, LocalDate of, String numu321654987, String number, String number1, String mail, String s);

        boolean GetUtente(int i);

        Object ListarUtentes();
}
