package interfaces;

import data.*;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;


public interface ProfissionalSaudeInterface extends Remote {
    public void ConsultarFichaUtente () throws RemoteException;
    public void AtualizarDadosUtente (String numutente, String telefone, String telefone_familiar, String email,String morada) throws RemoteException;
    public void EditarFichaUtente (LocalDateTime data, Utente utente, FamiliarUtente familiarUtente, List<Medicao> mediçoes, List<Prescricao> prescriçoes, List<Exames> exames, List<Consulta> consultas) throws RemoteException;

    }

