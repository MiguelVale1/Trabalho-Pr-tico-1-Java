package prog;

import data.FamiliarUtente;
import data.FichaUtente;
import data.ProfissionalSaude;
import data.Utente;
import data.excepcoes.ProfissionalExiste;
import data.excepcoes.ProfissionalNaoExiste;
import data.excepcoes.UtenteExiste;
import data.excepcoes.UtenteNaoExiste;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class PCmanager implements Serializable {

    private static final long serialVersionUID = -5257792212933286527L;


    private Map<String, FichaUtente> fichasUtenteMap;
    private Map<String, ProfissionalSaude> profissionalSaudeMap;
    private Map<Integer, FamiliarUtente> familiarUtenteMap;
    //private Map<String, Medicamento> medicamentos;
    //private Agenda agenda;

    public PCmanager() {
        fichasUtenteMap = new HashMap<>();
        profissionalSaudeMap = new HashMap<>();
        familiarUtenteMap = new HashMap<>();
    }

    public Map<String, FichaUtente> getFichasUtente() {
        return fichasUtenteMap;
    }

    public Map<String, ProfissionalSaude> getProfissionalSaude() {
        return profissionalSaudeMap;
    }

    public Map<Integer, FamiliarUtente> getFamiliarUtente() {
        return familiarUtenteMap;
    }


    /*
     * UTENTES
     * */
    //numutente

    private void AdicionaUtenteMap(Utente utenteinfo) throws UtenteExiste {
        if (this.fichasUtenteMap.containsKey(utenteinfo.getNumutente())) {
            throw new UtenteExiste();
        }
        this.fichasUtenteMap.put(utenteinfo.getNumutente(), new FichaUtente(utenteinfo));
    }

    public synchronized void AdicionaUtente(String nome, String nif,
                                            String cc, LocalDate datanasc, String numutente,
                                            String telefone, String telefone_familiar,
                                            String email, String morada) throws UtenteExiste {
        if (this.fichasUtenteMap.containsKey(numutente)) {
            throw new UtenteExiste();
        }
        Utente u = new Utente(nome, nif, cc, datanasc, numutente, telefone,
                telefone_familiar, email, morada);
        AdicionaUtenteMap(u);
    }


    public Utente getUtente(String numutente) throws UtenteNaoExiste {
        if (!this.fichasUtenteMap.containsKey(numutente)) {
            throw new UtenteNaoExiste();
        }
        return this.fichasUtenteMap.get(numutente).getUtente();
    }

    /*
     * PROFISSIONAL SAUDE
     * */
    public synchronized void AdicionaProfissionalSaude(String nome, String nif,
                                                       String cc, LocalDate datanasc,String num_trabalhador,
                                                       String profissao, String especialidade) throws ProfissionalExiste {
        if (this.profissionalSaudeMap.containsKey(num_trabalhador)) {
            throw new ProfissionalExiste();
        }
        ProfissionalSaude p = new ProfissionalSaude(nome, nif, cc, datanasc, num_trabalhador, profissao, especialidade);
        this.profissionalSaudeMap.put(num_trabalhador, p);
    }

    public ProfissionalSaude getProfissionalSaude(String num_trabalhador) throws ProfissionalNaoExiste {
        if (!this.profissionalSaudeMap.containsKey(num_trabalhador)) {
            throw new ProfissionalNaoExiste();
        }
        return this.profissionalSaudeMap.get(num_trabalhador);
    }

    /*
     * FAMILIAR UTENTE  exatamente o mesmo do que o anterior
     * */

    /*
     * FICHA UTENTE  como no outro trabalho mas mudar os nomes das estruturas e variaveis para os deste trabalho
     * */

    /*
     * CONSULTAS  como no outro trabalho mas mudar os nomes das estruturas e variaveis para os deste trabalho
     * */

}
