package server;

import configuracoes.Configuracoes;
import interfaces.ServicoSaude;
import prog.PCmanager;

import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


public class Servidor {

    public static void main(String[] args) throws RemoteException {
        //public class ProfissionalSaude implements ProfissionalSaudeInterface {
        //  public ProfissionalSaudeInterface () throws RemoteException {
        //    super();
        //}
        //public static void main(String[] args){
        //  try {
        //    ProfissionalSaudeInterface ProfissionalSaude = new ProfissionalSaude()}
        //}

        PCmanager admin = new PCmanager();

            // inicializando o gestor sem dados
        admin = new PCmanager();

        var service = new ServicoSaude(admin);

        // inicializando servidor RMI
        Registry registry = LocateRegistry.createRegistry(Configuracoes.rmiPort);
        registry.rebind(Configuracoes.rmiService, service);
        System.out.println(" \nServidor pronto!");

    }
}
